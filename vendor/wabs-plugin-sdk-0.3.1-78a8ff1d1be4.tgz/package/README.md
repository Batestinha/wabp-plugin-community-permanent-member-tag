# WABS plugin SDK

Version 0.3.1 supplies portable plugin manifests, service declarations, metadata-driven console controls, conditional templates, workflows, ephemeral storage and IANA timezone validation. Runtime services, account ownership and persistence stay in WABP and are passed through plugin contexts. The SDK never imports host source, production configuration or optional plugins.

Service providers use `ServicePlugin` and `ServicePluginContext`; implement only the capabilities they need. Hook providers use `HookPlugin` and `PluginHookContext`, returning declared actions for the host to authorize and execute. Portable event, transport, actor and group lifecycle contracts share canonical definitions with WABP. Command and lifecycle context extraction is in progress. Plugins continue to declare their `coreApiRange` and exact package dependencies. Shared metadata cannot grant lifecycle or deployment authority.

Build with the repository's pinned TypeScript compiler: `npm run plugin-sdk:build`. Publication must include the compiled runtime, declarations, license and exact dependency lock.
